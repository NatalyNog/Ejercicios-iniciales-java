public class Main {
    public static void main(String[] args) {
        var estacion = "invierno";

        switch (estacion) {
            case "invierno":
                System.out.println("Es invierno");
            case "verano":
                System.out.println("Es verano");
            case "primavera":
                System.out.println("Es primavera");
            case "otoño":
                System.out.println("Es otoño");
                break;
            default:
                System.out.println("No es una estacion");

        }
    }
}