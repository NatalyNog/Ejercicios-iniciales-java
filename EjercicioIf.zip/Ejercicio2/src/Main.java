public class Main {
    public static void main(String[] args) {
        String numero = "-1";

        if (numero == "1") {
            System.out.println("Es positivo");
        } else if (numero == "-1") {
            System.out.println("Es negativo");
        } else {
            System.out.println("0");
        }
            
        }
    }