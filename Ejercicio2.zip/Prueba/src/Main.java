public class Main {
    public static void main(String[] args) {
        Coche miCoche = new Coche();
        miCoche.PonerPuertas();
        miCoche.PonerPuertas();
        System.out.println(miCoche.Puertas);


    }
}

class Coche {
    public int Puertas = 4;

    public void PonerPuertas() {
        this.Puertas++;
    }
}