public class Main {
    public static void main(String[] args) {
        int contador = -2;

        while (contador < 3) {
            System.out.println(contador);
            contador = contador + 1;
        }
    }
}